OPEN index.html to view the website
